import { getStorage } from "firebase/storage";

export const storage = getStorage();
