# Velog-Copy

### **Goal**: Clone [Velog](https://velog.io/) to study React-ts

### How to join the project
1. git clone <project url>
2. cd Velog-Copy
3. npm install
4. npm run dev

### Tech Stack: React-ts, Vite, Jotai, React-Hook-Form, TailwindCss, Firebase
