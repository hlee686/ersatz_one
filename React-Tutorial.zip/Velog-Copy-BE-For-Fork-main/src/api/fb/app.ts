import { initializeApp } from "firebase/app";

const firebaseConfig = {};

export const app = initializeApp(firebaseConfig);
